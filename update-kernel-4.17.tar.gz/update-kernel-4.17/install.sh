# /bin/bash
# Author: baiyitong@hotmail.com
# Date: 2019-07-17
set -ex
cd $(dirname $(readlink -f $0))

function update_kernel() {
    yum remove -y kernel-tools*
    yum remove -y kernel-headers*

    rpm -qa |grep kernel-ml-tools-libs-4.17.11-1.el7.elrepo.x86_64 >> /dev/null || yum install -y kernel/kernel-ml-tools-libs-4.17.11-1.el7.elrepo.x86_64.rpm
    rpm -qa |grep kernel-ml-tools-4.17.11-1.el7.elrepo.x86_64 >> /dev/null || yum install -y kernel/kernel-ml-tools-4.17.11-1.el7.elrepo.x86_64.rpm
    rpm -qa |grep kernel-ml-tools-libs-devel-4.17.11-1.el7.elrepo.x86_64 >> /dev/null || yum install -y kernel/kernel-ml-tools-libs-devel-4.17.11-1.el7.elrepo.x86_64.rpm
    rpm -qa |grep kernel-ml-headers-4.17.11-1.el7.elrepo.x86_64 >> /dev/null || yum install -y kernel/kernel-ml-headers-4.17.11-1.el7.elrepo.x86_64.rpm
    rpm -qa |grep kernel-ml-devel-4.17.11-1.el7.elrepo.x86_64 >> /dev/null || yum install -y kernel/kernel-ml-devel-4.17.11-1.el7.elrepo.x86_64.rpm
    rpm -qa |grep kernel-ml-4.17.11-1.el7.elrepo.x86_64 >> /dev/null || yum install -y kernel/kernel-ml-4.17.11-1.el7.elrepo.x86_64.rpm
    mkdir -p /usr/src/kernel-src-4.17
    tar -xvf kernel/kernel-src-4.17.11-1.el7.x86_64.tar.gz -C /usr/src/kernel-src-4.17
    grub2-set-default 0
    grub2-reboot 0
}

update_kernel

echo "Kernel has updated to 4.17..."
echo "Please reboot manually..."
